@foreach($modelos as $modelo)
    {{$modelo->modelo}}
@endforeach