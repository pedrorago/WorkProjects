



<?php $__env->startSection('content'); ?>

 <!-- Page Heading -->

<?php function tirarAcentos($string){
    return preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/","/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/"),explode(" ","a A e E i I o O u U n N"),$string);
}
?>


<div class="d-sm-flex justify-content-between mb-4">

    <div class="d-sm-flex flex-column">
    <h1 class="h3 mb-0 text-gray-800">Capiba Projetos</h1>
    <p class="mb-4" style="margin-top: .4em">Aqui se encontra todos os projetos e sub projetos da Capiba.</p>
    <?php if(Auth::user()->type == 1 ): ?>
        <div class="buttons" style="margin-bottom: 1.4em">
            <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-secondary btn-icon-split">
                <span class="icon text-white-50">
                  <i class="fas fa-arrow-right"></i>
                </span>
                <span class="text">Adicionar um novo projeto</span>
              </a>
        </div>
        <?php endif; ?>
    </div>
    

    <form action="">
        <div class="form-group row d-sm-flex align-items-center">
                <label for="searchProject">Pesquisar</label>
                  <input class="form-control" placeholder='Pesquise pelo nome do projeto' name="search" type="text" id="searchProject">
            </div>
    </form>
</div>

<div class="ContentCustom">

    <?php 
    $letter = 'a';?>

    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($letter != $project->ordering)
    {
        ?>
            <h2 class="h3 mb-3 text-gray-800 titleOrigim <?php echo e(strtoupper($project->ordering)); ?>" style="width: 100%;">Ordem: <?php echo e(strtoupper($project->ordering)); ?></h2>
        <?php
        $letter = $project->ordering;
    }
    ?>

    <a href="<?php echo e(route('projects.show', ['project' => $project->id ])); ?>" class="BoxProjects">
            <div>
                <span>
                    <strong><?php echo e(substr(tirarAcentos($project->name), 0, 3)); ?></strong> 
                </span>
                <p><?php echo e($project->name); ?></p>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>