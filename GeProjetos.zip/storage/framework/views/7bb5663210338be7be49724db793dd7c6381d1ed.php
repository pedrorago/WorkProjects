<?php $__env->startSection('content'); ?>





<div class="d-sm-flex justify-content-between flex-column mb-4">

    <h1 class="h3 mb-0 text-gray-800">Visualizando um projeto</h1>

    <p class="mb-4" style="margin-top: .4em">Aqui se encontra todos os detalhes do projeto <?php echo e($project[0]->name); ?></a>.</p>

    

</div>

<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(Session::has('alert-' . $msg)): ?>
    
          <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div>

            <div class="card mb-12">

                <div class="card-header py-3 d-sm-flex justify-content-between align-items-center">

                  <h6 class="m-0 font-weight-bold text-primary"><?php echo e($project[0]->name); ?> >> <?php echo e($parent[0]->name); ?></h6>

                    <a href="<?php echo e(route('projects.edit', ['project' => $project[0]->id])); ?>" class="editA" style='color: #858796; font-size: 14px; display: flex; align-items: center;'>

                        Editar projeto <i class="fas fa-edit" style='font-size: 22px; margin-left: .5em;'></i>

                    </a>

                </div>

                <div class="card-body">

                  Filho de: <strong><?php echo e($parent[0]->name); ?></strong> | 
                  Criado em: <strong><?php echo e($project[0]->created_at); ?></strong> | 



                  <br/>

                  <br/>

                    <div class='projectBody' style="display: flex;
                    flex-direction: column;">

<?php if($project[0]->id != 7): ?>

<div class="familys">
    <?php if($gram != null): ?>
  
        <a href="<?php echo e(route('projects.show', [$gram[0]->id])); ?>" class='gram'>- <?php echo e($gram[0]->name); ?></a>
    <?php endif; ?>
  <a href="<?php echo e(route('projects.show', [$daddy[0]->id])); ?>" class='daddy'>-- <?php echo e($daddy[0]->name); ?></a>
  <a href="<?php echo e(route('projects.show', [$project[0]->id])); ?>" class='son'>---- <?php echo e($project[0]->name); ?></a>

  <?php $__currentLoopData = $brothers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brother): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo e(route('projects.show', [$brother->id])); ?>" class='brother'>---- <?php echo e($brother->name); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  

<?php endif; ?>


<h5>Tarefas do projeto:</h5>
<?php $__currentLoopData = $issuesOnProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<a href="<?php echo e(route('issues.show', [ 'issues' => $issue->id])); ?>" style="color: #000;"><?php echo e($issue->subject); ?> / <?php echo e($issue->name); ?></a>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

              </div>

</div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>