<?php $__env->startSection('content'); ?>

 <!-- Page Heading -->

 <h1 class="h3 mb-2 text-gray-800">Capiba Backlog</h1>

          <p class="mb-4">Aqui é se encontra um quadro geral de todas as atividades do backlog da Agencia Capiba. É possível fazer alterações, pesquisas e consultas nessa parte da aplicação.</a>.</p>



          <!-- DataTales Example -->

          <div class="card shadow mb-4">

            <div class="card-header py-3">

              <h6 class="m-0 font-weight-bold text-primary">Quadro do backlog</h6>

            </div>

            <div class="card-body">

              <div class="table-responsive">

                <table class="table table-bordered classTable" id="dataTable" width="100%" cellspacing="0">

                <thead>

    <tr>

      <th scope="col">Sprint</th>

      <th scope="col">Projeto</th>

      <th scope="col">Título</th>

      <th scope="col">Tipo</th>

      <th scope="col">Área</th>

      <th scope="col">Status</th>

      <th scope="col">Prioridade</th>


    </tr>

  </thead>

  <tbody>

    <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>

          <th scope="row">#<?php echo e($issue->version); ?></th>

          <td><?php echo e($issue->project); ?></td>

          <td><a href="<?php echo e(route('issues.show', ['issue' => $issue->id])); ?>"><?php echo e($issue->subject); ?></a></td>

          <td><?php echo e($issue->name); ?></td>

          <td><?php echo e($issue->function); ?></td>

          <td><?php echo e($issue->status); ?></td>

          <td><?php echo e($issue->priority); ?></td>


        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 

  </tbody>

                </table>

              </div>

            </div>

          </div>



        </div>

        <!-- /.container-fluid -->



      </div>

      <!-- End of Main Content -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>