<?php $__env->startSection('content'); ?>





<div class="d-sm-flex justify-content-between flex-column mb-4">

    <h1 class="h3 mb-0 text-gray-800">Criar uma nova tarefa</h1>

    <p class="mb-4" style="margin-top: .4em">Preencha o formulário abaixo</a>.</p>

    

</div>





<div>

    <form action="<?php echo e(route('issues.store')); ?>" class="form-horizontal" method="POST">

        <!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->

        

        <?php echo csrf_field(); ?>

        <input type="hidden" name="author_id" value="<?php echo e(Auth::user()->id); ?>">
        <input type="hidden" name="created_name" value="<?php echo e(Auth::user()->name); ?>">

        <div class="row">

            <div class="form-group col-md-4">

                <label for="subject">Título da tarefa:</label>

                <input type="text" id="subject" name="subject" placeholder="Preencha o título da tarefa" class="form-control">

            </div>

            

            <div class="form-group col-md-4">

                <label for="project_id">Projeto relacionado:</label>

                <select name="project_id" id="project_id" class="form-control">

                    <option value="">Selecione um projeto</option>

                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>

            <div class="form-group col-md-4">

                <label for="status_id">Status da tarefa:</label>

                <select name="status_id" id="status_id" class="form-control">

                    <option value="">Selecione um status</option>

                    <option value="1">A Fazer</option>

                    <option value="2">Fazendo</option>

                    <option value="3">Feito</option>

                    <option value="4">Bloqueado</option>

                    <option value="5">Aprovado</option>

                </select>

            </div>
            <div class="form-group col-md-4">

<label for="priority_id">Prioridade da tarefa:</label>

<select name="priority_id" id="priority_id" class="form-control">

    <option value="">Selecione uma prioridade</option>

    <option value="1">Baixa</option>

    <option value="2">Normal</option>

    <option value="3">Alta</option>

    <option value="4">Urgente</option>

</select>

</div>


        


            <div class="form-group col-md-4">

                    <label for="fixed_version_id">Versão da tarefa:</label>

                    <select name="fixed_version_id" id="fixed_version_id" class="form-control">

                        <option value="">Selecione uma versão</option>

                        <?php $__currentLoopData = $versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $versions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($versions->id); ?>"><?php echo e($versions->name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>



                <div class="form-group col-md-4">

                        <label for="tracker_id">Tipo da tarefa:</label>

                        <select name="tracker_id" id="tracker_id" class="form-control">

                            <option value="">Selecione um tipo</option>

                            <?php $__currentLoopData = $trackers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tracker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($tracker->id); ?>"><?php echo e($tracker->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                    </div>
                    <div class="form-group col-md-4">



<label for="funcion_id">Área da tarefa:</label>


<select  name="funcion_id" id="funcion_id" class="form-control">

    <option value="">Selecione uma área</option>

    <?php $__currentLoopData = $Functions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($Function->id); ?>"><?php echo e($Function->name); ?></option>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>

</div>
<div class="form-group col-md-4">
                        <label for="start_date">Prazo da tarefa</label>
                          <input class="form-control" name="due_date" type="date" id="due_date">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="start_date">Atribuir tarefa para:</label>
                        <select name="assigned_to_id" id="assigned_to_id"  class="form-control">
                        <option value="69">Nenhuma atribuição</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($user->id == Auth::user()->id): ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (EU)</option>
                            <?php else: ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
        </div>
   

        </div>
        <div class="row">

            <div class="form-group col-md-12">

                <label for="description">Descrição da tarefa</label>

                <textarea name="description" id="summernote" class="form-control"></textarea>

            </div>

        </div>

        <div class="row col-md-12">

            <div class="form-group">

                <button type="submit" class="btn btn-primary">Cadastrar</button>

            </div>

        </div>

    </form>

</div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>