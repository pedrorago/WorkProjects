



<?php $__env->startSection('content'); ?>




 <!-- Page Heading -->

 <h1 class="h3 mb-2 text-gray-800">Capiba Sprints</h1>

          <p class="mb-4">Aqui se encontra o quadro de todas as sprints criadas pela Capiba</a>.</p>
          <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(Session::has('alert-' . $msg)): ?>
    
          <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <?php if(Auth::user()->type == 1 ): ?>
        <div class="buttons" style="margin-bottom: 1.4em">
            <a href="<?php echo e(route('sprints.create')); ?>" class="btn btn-secondary btn-icon-split">
                <span class="icon text-white-50">
                  <i class="fas fa-arrow-right"></i>
                </span>
                <span class="text">Adicionar uma nova sprint</span>
              </a>
        </div>
        <?php endif; ?>

          <!-- DataTales Example -->

          <div class="card shadow mb-4">

            <div class="card-header py-3">

              <h6 class="m-0 font-weight-bold text-primary">Quadro de sprints</h6>

            </div>

            <div class="card-body">

              <div class="table-responsive">

                <table class="table table-bordered classTable" id="sprints" width="100%" cellspacing="0">

                <thead>

    <tr>

      <th scope="col">ID</th>

      <th scope="col">Sprint</th>

      <th scope="col">Situação</th>

      <th scope="col">Data de início</th>

      <th scope="col">Data de conclusão</th>
      <?php if(Auth::user()->type == 1 ): ?>
        <th scope="col">Ação</th>
      <?php endif; ?>
    </tr>

  </thead>

  <tbody>

    <?php $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
        
        if($sprint->status == 'open')
        {
            $sprint->status = 'Aberta';
            $classeClose = '';
        }
        else
        {
            $sprint->status = 'Fechada';
            $classeClose = 'table-secondary';

        }
        if($sprint->active == 1)
        {
            $claseActive = 'table-primary';
        }
        else
        {
            $claseActive = '';
        }

        ?>

            <tr class="<?php echo e($classeClose); ?> <?php echo e($claseActive); ?> ">
                <?php if(Auth::user()->type == 1 ): ?>
                <th scope="row"><a href="<?php echo e(route('sprints.edit', ['sprint' => $sprint->id])); ?>">#<?php echo e($sprint->id); ?></a></th>
                <?php else: ?>
                <th scope="row">#<?php echo e($sprint->id); ?></th>
                <?php endif; ?>
                <?php if(Auth::user()->type == 1 ): ?>
                <td><a href="<?php echo e(route('sprints.edit', ['sprint' => $sprint->id])); ?>"><?php echo e($sprint->name); ?></a></td>
                <?php else: ?>
                <td><?php echo e($sprint->name); ?></td>
                <?php endif; ?>
                <td><?php echo e($sprint->status); ?></td>
                <td><?php echo e($sprint->start_date); ?></td>
                <td><?php echo e($sprint->finish_date); ?></td>
                <?php if(Auth::user()->type == 1 ): ?>
                <td>   <form action="<?php echo e(route('sprints.destroy', ['sprint' => $sprint->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-secondary btn-icon-split">
                                <span class="icon text-white-50">
                                  <i class="fas fa-trash"></i>
                                </span>
                                <span class="text" style="color: #fff">Remover</span>
                        </button></i>
                </form>
                </td>
                <?php endif; ?>
            </tr>
         
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


 

  </tbody>

                </table>

              </div>

            </div>

          </div>



        </div>

        <!-- /.container-fluid -->



      </div>

      <!-- End of Main Content -->





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>