<?php $__env->startSection('content'); ?>


<div class="d-sm-flex justify-content-between flex-column mb-4">
    <h1 class="h3 mb-0 text-gray-800">Visualizando uma tarefa</h1>
    <p class="mb-4" style="margin-top: .4em">Aqui se encontra todos os detalhes da tarefa <?php echo e($issue[0]->subject); ?></a>.</p>
    
</div>


<div>
<div class="card mb-12">
                <div class="card-header py-3 d-sm-flex justify-content-between align-items-center">
                  <h6 class="m-0 font-weight-bold text-primary"><?php echo e($issue[0]->subject); ?> - <?php echo e($issue[0]->project); ?> </h6>
                    <a href="<?php echo e(route('issues.edit', ['issue' => $issue[0]->id])); ?>" class="editA" style='color: #858796; font-size: 14px; display: flex; align-items: center;'>
                        Editar tarefa <i class="fas fa-edit" style='font-size: 22px; margin-left: .5em;'></i>
                    </a>
                </div>
                <div class="card-body">
                  Setor: <strong><?php echo e($issue[0]->name); ?></strong> | 
                  Projeto: <strong><?php echo e($issue[0]->project); ?></strong> | 
                  Status: <strong><?php echo e($issue[0]->status); ?></strong> | 
                  Situação: <strong><?php echo e($issue[0]->priority); ?></strong> | 
                  Versão: <strong><?php echo e($issue[0]->version); ?></strong> | 

                  <br/>
                  <br/>
                  <?php echo e($issue[0]->description); ?>

                </div>
              </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>