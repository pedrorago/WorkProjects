<?php $__env->startSection('content'); ?>

<div class="d-sm-flex justify-content-between flex-column mb-4">
  
  <h1 class="h3 mb-0 text-gray-800">Visualizando uma tarefa</h1>
  
  <p class="mb-4" style="margin-top: .4em">Aqui se encontra todos os detalhes da tarefa <?php echo e($issue[0]->subject); ?></a>.</p>
  
  
  
</div>

<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Session::has('alert-' . $msg)): ?>

<p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div>
  
  <div class="card mb-12">
    
    <div class="card-header py-3 d-sm-flex justify-content-between align-items-center">
      
      <h6 class="m-0 font-weight-bold text-primary titleIssue"><?php echo e($issue[0]->subject); ?> - <?php echo e($issue[0]->project); ?> 
        <div class='boxUsericon showIssue'>
          <div class='boxAttrImg'>
            <?php if( $issue[0]->attr_id != 69): ?>
            <img src="<?php echo e($issue[0]->attr_img); ?>" alt="">
            <?php endif; ?>
          </div>
          
          <span class='boxAttr'>
            <?php if( $issue[0]->attr_id != 69): ?>
            Atividade atribuida para <strong><?php echo e($issue[0]->attr); ?></strong>
            <?php else: ?>
            Atividade sem atribuição
            <?php endif; ?>
            
          </span>
        </div>
      </h6>
      
      <div class='actions'>
        <a href="<?php echo e(route('issues.edit', ['issue' => $issue[0]->id])); ?>" class="editA" style='color: #858796; font-size: 14px; display: flex; align-items: center;'>
          
          Editar tarefa <i class="fas fa-edit" style='font-size: 22px; margin-left: .5em;'></i>
          
        </a>
        
        <?php if(Auth::user()->type == 1): ?>
        
        <form action="<?php echo e(route('issues.destroy', ['issue' => $issue[0]->id])); ?>" method="post" style='position: relative'>
          <?php echo csrf_field(); ?>
          
          <?php echo method_field('DELETE'); ?>

            
          <div class='ConfirmDelete'>
                          <p>Confirmar exclusão</p>
                          <span>
                            <button type='button' class='nDelete'>Cancelar</button>
                            <button type='submit' class='yDelete'>Confirmar</button>
                          </span>
                      </div>



          <input type="hidden" name='url' id='url' value="internal">
          <button type="button" class="btn btn-secondary btn-icon-split buttonEditDelete">
            <span class="icon text-white-50">
              <i class="fas fa-trash"></i>
            </span>
            <span class="text" style="color: #fff">Remover</span>
          </button></i>
        </form>
        
        <?php endif; ?>
        
      </div>
    </div>
    
    <div class="card-body">
      
      Tipo: <strong><?php echo e($issue[0]->name); ?></strong> | 
      Area: <strong><?php echo e($issue[0]->function); ?></strong> | 
      
      Projeto: <strong><?php echo e($issue[0]->project); ?></strong> | 
      
      Status: <strong><?php echo e($issue[0]->status); ?></strong> | 
      
      Situação: <strong><?php echo e($issue[0]->priority); ?></strong> | 
      
      Versão: <strong>Sprint <?php echo e($issue[0]->version); ?></strong> |
      Prazo: <strong> <?php echo e($issue[0]->due_date); ?></strong> 
      Autor: <strong> <?php echo e($issue[0]->created_name); ?></strong> 
      
      
      <br/>
      
      <br/>
      
      
      <?php if($issue[0]->status_id == 2): ?>
      <div class="doingBox" style='border-bottom: 0px'>
        <span class="doingImg"> 
          <img src="<?php echo e($issue[0]->author_pic); ?>" alt="">
        </span>
        <p><strong><?php echo e($issue[0]->author_name); ?></strong><br/>
          Está fazendo essa tarefa.
          
        </p>
      </div>
      <?php endif; ?>
      <div class='descriptionBody'>
        <?php echo e($issue[0]->description); ?>

      </div>
      
    </div>
    
  </div>
  
</div>

<div class='row contentShow'  style='margin-top:3em; display: flex; justify-content: space-between'>
  
  <div class="card mb-12">
    
    <div class="card-header py-3 d-sm-flex justify-content-between align-items-center">
      
      <h6 class="m-0 font-weight-bold text-primary">Área de comentários</h6>
      <a href="<?php echo e(route('issues.show', ['issue' => $issue[0]->id, 'comment' => 'true'])); ?>" class="editA" style='color: #858796; font-size: 14px; display: flex; align-items: center;'>
        Adicionar um comentário <i class="fas fa-comment-medical" style='font-size: 22px; margin-left: .5em;'></i>
      </a>
    </div>
    
    <div class="card-body boxComments" style='max-height: 32em; overflow: auto;'>
      <?php if(Session::has('create-comment')): ?>
      <form action="<?php echo e(route('comments.store', ['issue' => $issue[0]->id ])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <textarea name="comments_text" id="summernote" class="form-control"></textarea>
        <input type="hidden" name='author_id' value='<?php echo e(Auth::user()->id); ?>'>
        <input type="hidden" name='issue_id' value='<?php echo e($issue[0]->id); ?>'>
        
        <div>
          <button type='submit' class="btn btn-primary btn-icon-split" style='    margin-top: 1em;
          margin-bottom: 3em;'>
          <span class="icon text-white-50">
            <i class="fas fa-check"></i>
          </span>
          <span class="text">Adicionar comentário</span>
        </button>
        
        <a href="<?php echo e(route('issues.show', ['issue' => $issue[0]->id])); ?>" class="btn btn-secondary btn-icon-split" style='    margin-top: 1em;
          margin-bottom: 3em;'>
          <span class="icon text-white-50">
            <i class="fas fa-trash"></i>
          </span>
          <span class="text">Cancelar</span>
        </a>
      </div>
      
      
    </form>
    <?php endif; ?>
    
    
    <?php if($comments == 'Sem comentários existentes'): ?>
    
    <p>Nenhum comentário existente.</p>
    
    <?php else: ?>
    
    
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="doingBox" style='border-bottom: 0px; margin-bottom: 0px'>
      <span class="doingImg"> 
        <img src="<?php echo e($comment->avatar); ?>" alt="">
      </span>
      <p><strong><?php echo e($comment->user_name); ?> <i style='font-weight: 300; font-size: 13px; margin-left: 1px;'><?php echo e($comment->create); ?></i></strong><br/>
        Comentou:
      </p>
      <div class='commentBody'>
        <?php echo e($comment->comments_text); ?> 
      </div>
      <br/>
      <?php if(Auth::user()->id == $comment->author_id): ?>
      <form action="<?php echo e(route('comments.destroy', ['issue' => $issue[0]->id, 'comment' => $comment->id])); ?>" method='post'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="hidden" value='<?php echo e($issue[0]->id); ?>' name='issue_id'>
        <button style='padding-bottom: 2em;margin-bottom: 2em;width: 100%;display: flex;align-items: center;background: transparent;border: 0;color: #737373;border-bottom: 1px solid #eeee;'><i class="fas fa-trash" style='font-size: 22px; margin-right: .5em;'></i>Remover comentário</button>
      </form>
      <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </div>
  
  
  
  
</div>






<div class="card mb-12">
  
  <div class="card-header py-3 d-sm-flex justify-content-between align-items-center">
    
    <h6 class="m-0 font-weight-bold text-primary titleIssue">Checklist</h6>
    
  </div>
  
  <div class="card-body">
    <form class='updateForm'>
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <ul class="list-items">
        
        <?php $__currentLoopData = $checklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="item">
          <input type="hidden" name='id' id='id_checklist' value='<?php echo e($value->id); ?>'>
          <?php if($value->status == 'open'): ?>
          <input type="checkbox" class="checkbox">
          <?php else: ?>
          <input type="checkbox" class="checkbox" checked>
          <?php endif; ?>
          <label for=""><?php echo e($value->name); ?></label>
          <span><i class="fas fa-check"></i></span>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </ul>
    </form>
    <div class='RodapeList'>
      <form class='CreateNew' method='GET'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('GET'); ?>
        <input type='hidden' name='issue_id' id='issue_id' value='<?php echo e($issue[0]->id); ?>'>
        <div class='ContentList ContentListActive'>
          <textarea name="name" id='name' placeholder='Digite aqui' id=""></textarea>
          <button type="submit" class="btn btn-primary">Adicionar</button>
        </div>
      </form>
      
      <form id='deleteArea'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <i class="fas fa-trash-alt"></i>
      </form>
      
    </div>
    
  </div>
  
  
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>