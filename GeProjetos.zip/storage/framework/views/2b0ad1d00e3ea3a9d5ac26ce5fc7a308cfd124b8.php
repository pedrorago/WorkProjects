<?php $__env->startSection('content'); ?>

<!-- Page Heading -->

<h1 class="h3 mb-2 text-gray-800">Capiba Atividades</h1>

<p class="mb-4">Aqui é se encontra um quadro geral de todas as atividades da Agencia Capiba. É possível fazer alterações, pesquisas e consultas nessa parte da aplicação.</a>.</p>

<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Session::has('alert-' . $msg)): ?>

<p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php 
?>
<!-- DataTales Example -->

<?php
    $url_atual= "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";


    $serve = "http://$_SERVER[HTTP_HOST]";
?>

<input type='hidden' id='url' value='<?php echo e($url_atual); ?>'>
<input type='hidden' id='serve' value='<?php echo e($serve); ?>'>
<ul class='custom-menu shadow'>
  <input type='hidden' class='user' name='id_user' value='<?php echo e(Auth::user()->id); ?>'>
  <li class="menuLi six" ><a href="#" target="_blank" class='ListLink visuMenu'><img src="<?php echo e(asset('img/icons/open.png')); ?>"> Visualizar Tarefa</a></li>
  <li class="menuLi first" data-action="first"><a href="" class='ListLink'> <img src="<?php echo e(asset('img/icons/Status.png')); ?>"> Editar Status <i class="material-icons">arrow_right</i></a>
    <form id="form_status" class='submenu'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label class='labelMenuStatus' for="1">A Fazer</label>
        <input type="radio" name='status' value='1' hidden id='1'>

        <label class='labelMenuStatus' for="2">Fazendo</label>
        <input type="radio" name='status' value='2' hidden id='2'>

        <label class='labelMenuStatus' for="3">Feito</label>
        <input type="radio" name='status' value='3' hidden id='3'>

        <label class='labelMenuStatus' for="4">Bloqueado</label>
        <input type="radio" name='status' value='4' hidden id='4'>

        <label class='labelMenuStatus' for="5">Aprovado</label>
        <input type="radio" name='status' value='5' hidden id='5'>
    </form>
  </li>
  <li class="menuLi second" data-action="second"><a href="" class="ListLink"><img src="<?php echo e(asset('img/icons/Attr.png')); ?>"> Editar Atribuição<i class="material-icons">arrow_right</i></a>
    <form id="form_attr" class='submenu'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($user->name == Auth::user()->name)
          { 
            $user->name = $user->name." (EU)";
          } ?>
          <label class='labelAttr' for="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></label>
          <input type="radio" name='attr' value='<?php echo e($user->name); ?>' hidden id='<?php echo e($user->id); ?>'>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>  
</li>
  <li class='menuLi third' data-action="third"><a href="" class="ListLink"><img src="<?php echo e(asset('img/icons/priority.png')); ?>"> Editar Prioridade <i class="material-icons">arrow_right</i></a>
    <form id='form_priority' class='submenu'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label class='labelPriority' for="1">Baixa</label>
        <input type="radio" name='priority' value='1' hidden id='1'>

        <label class='labelPriority' for="2">Normal</label>
        <input type="radio" name='priority' value='2' hidden id='2'>

        <label class='labelPriority' for="3">Alta</label>
        <input type="radio" name='priority' value='3' hidden id='3'>

        <label class='labelPriority' for="4">Urgente</label>
        <input type="radio" name='priority' value='4' hidden id='4'>

    </form>  
</li>
  <li class="menuLi four" data-action="four"><a href="" class="ListLink"><img src="<?php echo e(asset('img/icons/move.png')); ?>"> Mover Tarefa <i class="material-icons">arrow_right</i></a>

    <form id='form_versios' class='submenu'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label class='labelVersions' for="<?php echo e($backlog[0]->id); ?>"><?php echo e($backlog[0]->name); ?></label>
        <input type="radio" name='versios' value='<?php echo e($backlog[0]->id); ?>' hidden id='<?php echo e($backlog[0]->id); ?>'>        

        
        <?php $__currentLoopData = $lastVersios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <label class='labelVersions' for="<?php echo e($version->id); ?>"><?php echo e($version->name); ?></label>
          <input type="radio" name='versios' value='<?php echo e($version->id); ?>' hidden id='<?php echo e($version->id); ?>'>        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>  

</li>
  <!-- <li class='menuLi five' data-action="five"><a href="" class="ListLink"><img src="<?php echo e(asset('img/icons/Remove.png')); ?>"> Remover Tarefa </a></li> -->
</ul>


<div class="card shadow mb-4">
  
  <div class="card-header py-3">
    
    <h6 class="m-0 font-weight-bold text-primary">Quadro geral</h6>
    
  </div>
  
  <div class="card-body">
    
    <div class="table-responsive">
      
      <table class="table table-bordered classTable issuesTable" id="dataTable" width="100%" cellspacing="0">
        
        <thead>
          
          <tr>
            
            <th scope="col">ID</th>
            
            <th scope="col">Projeto</th>
            
            <th scope="col">Título</th>
            
            <th scope="col">Tipo</th>
            
            <th scope="col">Área</th>
            <th scope="col">Prioridade</th>
            <th scope="col">Status</th>
            
            
            <th scope="col">Sprint</th>
            <th scope="col" style="width: 73px !important">Prazo</th>
            <!-- <th scope="col" style='min-width: 5em;'>Extras</th> -->
            <th scope="col" style='width: 30px !important' >Extras</th>
            
            
          </tr>
          
        </thead>
        
        <tbody>
          
          <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($issue->status == 'Fazendo'): ?>
          <tr class='table-primary trStatus'>
            <?php else: ?>
            <tr>
              <?php endif; ?>
              
              
              
              <th scope="row">#<a href="<?php echo e(route('issues.show', ['issue' => $issue->id])); ?>" class='idIssue'><?php echo e($issue->id); ?></a></th>
              
              <td><?php echo e($issue->project); ?></td>
              
              <td class="NameTD">
                <a href="<?php echo e(route('issues.show', ['issue' => $issue->id])); ?>"><?php echo e($issue->subject); ?></a>
                
                <?php if($issue->status == 'Fazendo'): ?>
                <div class="statusBox">
                  <span>
                    <img src="<?php echo e($issue->author_pic); ?>" alt="">
                  </span>
                  
                  <p>
                    <strong><?php echo e($issue->author_name); ?></strong>
                    Está fazendo essa tarefa nesse momento.
                  </p>
                  
                </div>
                <?php endif; ?>
                
              </td>
              
              <td><?php echo e($issue->name); ?></td>
              
              <td><?php echo e($issue->function); ?></td>
              
              
              
              <td><?php echo e($issue->priority); ?></td>
              <?php if(empty($issue->due_date)){
                $issue->due_date = '0000-00-00';
              }else
              {
                $issue->due_date = $issue->due_date;
              } ?>
              <td><?php echo e($issue->status); ?></td>
              
              <td>#<?php echo e($issue->version); ?></td>
              
              <td><?php echo e($issue->due_date); ?></td>
              
              <td class='td_extra'>
                <div class='extras' style='justify-content: center'>
                  <?php if($issue->attr_id != 69){ ?>
                    
                    <div class='boxUsericon'>
                      <div class='boxAttrImg'>
                        <img src="<?php echo e($issue->attr_img); ?>" alt="">
                      </div>
                      <span class='boxAttr'>Atividade atribuida para <strong><?php echo e($issue->attr); ?></strong></span>
                    </div>
                    <?php } else
                    {
                      ?>
                      
                      <div class='boxUsericon'>
                        <div class='boxAttrImg'>
                        </div>
                        <span class='boxAttr'>Nenhuma atribuição para essa tarefa</span>
                      </div>
                      <?php
                    }
                    ?>
                    
                    <div class='Comments'>
                      <?php if($issue->comments_count != 0): ?>
                      <i class="fas fa-comment-alt"></i>
                      <span class="badge badge-danger badge-counter"><?php echo e($issue->comments_count); ?></span>
                      <?php else: ?>
                      <i class="fas fa-comment-alt" style='opacity: 0.3'></i>
                      
                      <?php endif; ?>
                      
                      
                    </div>
                    <?php if(Auth::user()->type == 1): ?>
                    
                    <form action="<?php echo e(route('issues.destroy', ['issue' => $issue->id])); ?>" method="post" class='formDelete'>
                      <?php echo csrf_field(); ?>
                      
                      <?php echo method_field('DELETE'); ?>
                      
                      <div class='ConfirmDelete'>
                          <p>Confirmar exclusão</p>
                          <span>
                            <button type='button' class='nDelete'>Cancelar</button>
                            <button type='submit' class='yDelete'>Confirmar</button>
                          </span>
                      </div>

                      <input type="hidden" name='url' id='url' value="<?php echo e($_SERVER['REQUEST_URI']); ?>">
                      <button type="button" class='deleteIndex'>
                        <i class='fas fa-trash'>
                        </button></i>
                      </form>
                      
                      
                      <?php endif; ?>
                      
                    </div>
                  </td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                
              </tbody>
              
            </table>
            
          </div>
          
        </div>
        
      </div>
      
      
      
    </div>
    
    <!-- /.container-fluid -->
    
    
    
  </div>
  
  <!-- End of Main Content -->
  
  <?php $__env->stopSection(); ?>
  
  
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>