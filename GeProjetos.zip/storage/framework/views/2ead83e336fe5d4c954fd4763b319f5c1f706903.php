<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-12">
        <form action="<?php echo e(route('modelo.store')); ?>" class="form-horizontal" method="POST">
            <!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
            
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="form-group">
                    <label for="modelo">Modelo do carro</label>
                    <input type="text" id="modelo" name="modelo" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="form-group">
                   <label for="status">Status</label>
                   <select name="status" id="status" class="form-control">
                       <option value="Ativo">Ativo</option>
                       <option value="Inativo">Inativo</option>
                   </select>
                </div>
            </div>
            <div class="row">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Cadastrar</button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>