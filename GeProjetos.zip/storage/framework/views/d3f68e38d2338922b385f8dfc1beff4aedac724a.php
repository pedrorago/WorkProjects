<?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($modelo->modelo); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>