<?php $__env->startSection('content'); ?>

 <!-- Page Heading -->

 <h1 class="h3 mb-2 text-gray-800">Capiba Atividades</h1>

          <p class="mb-4">Aqui é se encontra um quadro geral de todas as atividades da Agencia Capiba. É possível fazer alterações, pesquisas e consultas nessa parte da aplicação.</a>.</p>

          <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(Session::has('alert-' . $msg)): ?>
    
          <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php 
        ?>
          <!-- DataTales Example -->

          <div class="card shadow mb-4">

            <div class="card-header py-3">

              <h6 class="m-0 font-weight-bold text-primary">Quadro geral</h6>

            </div>

            <div class="card-body">

              <div class="table-responsive">

                <table class="table table-bordered classTable" id="dataTable" width="100%" cellspacing="0">

                <thead>

    <tr>

      <th scope="col">ID</th>

      <th scope="col">Projeto</th>

      <th scope="col">Título</th>

      <th scope="col">Tipo</th>

      <th scope="col">Área</th>
    <th scope="col">Prioridade</th>
      <th scope="col">Status</th>

  
      <th scope="col">Sprint</th>
      <th scope="col" style="width: 73px !important">Prazo</th>
      <!-- <th scope="col" style='min-width: 5em;'>Extras</th> -->
      <th scope="col" style='width: 30px !important' >Extras</th>


    </tr>

  </thead>

  <tbody>

    <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($issue->status == 'Fazendo'): ?>
        <tr class='table-primary trStatus'>
        <?php else: ?>
        <tr>
        <?php endif; ?>



          <th scope="row"><a href="<?php echo e(route('issues.show', ['issue' => $issue->id])); ?>"><?php echo e($issue->id); ?></a></th>

          <td><?php echo e($issue->project); ?></td>

          <td class="NameTD">
            <a href="<?php echo e(route('issues.show', ['issue' => $issue->id])); ?>"><?php echo e($issue->subject); ?></a>
  
            <?php if($issue->status == 'Fazendo'): ?>
            <div class="statusBox">
                <span>
                  <img src="<?php echo e($issue->author_pic); ?>" alt="">
                </span>
    
                <p>
                  <strong><?php echo e($issue->author_name); ?></strong>
                  Está fazendo essa tarefa nesse momento.
                </p>
    
              </div>
            <?php endif; ?>
    
          </td>

          <td><?php echo e($issue->name); ?></td>

          <td><?php echo e($issue->function); ?></td>

       

          <td><?php echo e($issue->priority); ?></td>
          <?php if(empty($issue->due_date)){
            $issue->due_date = '0000-00-00';
          }else
          {
            $issue->due_date = $issue->due_date;
          } ?>
   <td><?php echo e($issue->status); ?></td>

<td>#<?php echo e($issue->version); ?></td>

          <td><?php echo e($issue->due_date); ?></td>

          <td>
            <div class='extras' style='justify-content: center'>
            <?php if($issue->attr_id != 69){ ?>

            <div class='boxUsericon'>
                <div class='boxAttrImg'>
                  <img src="<?php echo e($issue->attr_img); ?>" alt="">
                </div>
                <span class='boxAttr'>Atividade atribuida para <strong><?php echo e($issue->attr); ?></strong></span>
            </div>
            <?php } else
            {
              ?>

<div class='boxUsericon'>
                <div class='boxAttrImg'>
                </div>
                <span class='boxAttr'>Nenhuma atribuição para essa tarefa</span>
            </div>
              <?php
            }
            ?>

          <div class='Comments'>
            <?php if($issue->comments_count != 0): ?>
            <i class="fas fa-comment-alt"></i>
                            <span class="badge badge-danger badge-counter"><?php echo e($issue->comments_count); ?></span>
            <?php else: ?>
            <i class="fas fa-comment-alt" style='opacity: 0.3'></i>

            <?php endif; ?>


            </div>
            <?php if(Auth::user()->type == 1): ?>

            <form action="<?php echo e(route('issues.destroy', ['issue' => $issue->id])); ?>" method="post" class='formDelete'>
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('DELETE'); ?>

                        <input type="hidden" name='url' id='url' value="<?php echo e($_SERVER['REQUEST_URI']); ?>">
                        <button type="submit" class='deleteIndex'>
                        <i class='fas fa-trash'>
                        </button></i>
                </form>
            

                <?php endif; ?>

            </div>
          </td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 

  </tbody>

                </table>

              </div>

            </div>

          </div>



        </div>

        <!-- /.container-fluid -->



      </div>

      <!-- End of Main Content -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>